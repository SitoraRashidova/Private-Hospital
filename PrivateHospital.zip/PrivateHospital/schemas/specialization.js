const {Schema, model} = require("mongoose");
const specializationSchema = new Schema( {
    specialization_name: {
        type: String,
        required: true,
        unique: true,  
        trim: true
    },
    description: {
        type: String,
        trim: true,  
        default: false 
    }
}, 
{
    versionKey: false
}
)
module.exports = model("Specialization", specializationSchema);