const {Schema, model} = require("mongoose");
const qualificationSchema = new Schema( {
    qualification_name: {
        type: String,
        required: true,
        trim: true
    },
    institution: {
        type: String,
        required: true,
        trim: true
    },
    year_obtained: {
        type: Number,
        required: true,
        min: 1900,  
        max: new Date().getFullYear()  
    },
    description: {
        type: String,
        trim: true,
        default: false  
    }
}, 
{
    versionKey: false
}
)
module.exports = model("Qualification", qualificationSchema);