const {Schema, model} = require("mongoose");
const doctorSchema = new Schema( {
    fullname: {
        type: String,
        required: true,
        trim: true
    },
    birth_date: {
        type: String,
        required: true
    },
    gender: {
        type: String,
        required: true,
        enum: ['Male', 'Female', 'Other']  
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    password: {
        type: String,
        required: true
      },
    phone: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    address: {
        type: String,
        required: true,
        trim: true
    },
    specialization_id: {
        type: Schema.Types.ObjectId,
        ref: 'Specialization'
    },
    experience: {
        type: Number,
        required: true,
        min: 0  
    },
    qualification_id: {
        type: Schema.Types.ObjectId,
        ref: 'Qualification'
    },
    consultation_fee: {
        type: Number,
        required: true,
        min: 0  
    },
    available_hours: {
        type: String,  
        required: true,
        trim: true
    },
    department_id: {
        type: Schema.Types.ObjectId,
        ref: 'Department'
    },
    active_status: {
        type: String,
        required: true,
        enum: ['Active', 'On Leave', 'Retired', 'Inactive'] 
    }
}, {
    versionKey: false
}
)
module.exports = model("Doctor", doctorSchema);