const {Schema, model} = require("mongoose");
const departmentSchema = new Schema( {
    department_name: {
        type: String,
        required: true,
        unique: true,  
        trim: true
    },
    description: {
        type: String,
        trim: true,  
        default: false
    },
    head_of_department: {
        type: Schema.Types.ObjectId,
        ref: 'Doctor',  
        required: true
    },
    contact_number: {
        type: String,
        required: true,
        trim: true,
        match: [/^\+?[1-9]\d{1,14}$/, 'Please provide a valid contact number.'] 
    },
    email: {
        type: String,
        required: true,
        unique: true, 
        trim: true,
        match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address.'] 
    }, 
    location: {
        type: String,
        required: true,
        trim: true 
    },
    operating_hours: {
        type: String,
        required: true,
        trim: true 
    },
    services_offered: {
        type: [String],  
        default: []
    },
    number_of_staff: {
        type: Number,
        required: true,
        min: 1  
    }
}, 
{
    versionKey: false
}
)
module.exports = model("Department", departmentSchema);