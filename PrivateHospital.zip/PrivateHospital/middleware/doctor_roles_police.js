const myJwt = require("../services/jwt_service")
const {to} = require('../helpers/to_promise');

module.exports = function(roles) {
    return async function(req, res, next) {
        try {
            const doctorization = req.headers.doctorization
            if(!doctorization){
              return res.status(403).send({message: "Token berilmagan!"});
            }
            const [bearer, token] = doctorization.split(" ");
            if(bearer!="Bearer"|| !token) {
               return res.status(403).send({ message: "Token noto'g'ri!" });
            }
            const [error, decodedToken] = await to(myJwt.verifyAccessToken(token)) ;
            if(error){
                return res.status(403).send({ error: error.message});
            }
            req.doctor = decodedToken; 
            const{is_expert, doctor_roles} = decodedToken
            let hasRole = false
            doctor_roles.forEach((doctor_role) => {
                if(roles.includes(doctor_role)) hasRole = true
            })
            if(!is_expert || !hasRole) {
                return res.status(401).send({message: "Sizga bunday huquq berilmagan!"})
            }
            console.log(decodedToken);
            
            next()
        } catch (error) {
            console.log(error);
            res.status(403).send({message: "Doktor ro'yxatdan o'tmagan!"})
        }
    }
}

