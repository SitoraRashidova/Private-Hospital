const Joi = require("joi");

exports.doctorValidation = (data) => {
    const doctorSchema = Joi.object(
        {
        fullname: Joi.string().trim().messages('Name must be a string'),
        email: Joi.string().email().lowercase().trim().messages('Email must be a string'),
        phone: Joi.string().messages('Phone must be a string'),
        password: Joi.string(),
        gender: Joi.string().valid("erkak", "ayol").messages('Gender must be a string'),
        birth_date: Joi.date().less(new Date("2010-01-01")).greater(new Date("2000-01-01")),
    });
    return doctorSchema.validate(data, {abortEarly: false})
}
