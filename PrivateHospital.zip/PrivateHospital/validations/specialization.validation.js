const Joi = require('joi');

exports.specializationValidation = (data) => {
    const specializationSchema = Joi.object({
        specialization_name: Joi.string().trim().required(),
        description: Joi.string().trim().allow(''),
    });
    return specializationSchema.validate(data, { abortEarly: false });
};
