const Joi = require('joi');

exports.qualificationValidation = (data) => {
    const qualificationSchema = Joi.object({
        qualification_name: Joi.string().trim().required(),
        institution: Joi.string().trim().required(),
        year_obtained: Joi.number().integer().min(1900).max(new Date().getFullYear()).required(),
        description: Joi.string().trim().default(false),
    });
    return qualificationSchema.validate(data, { abortEarly: false });
};
