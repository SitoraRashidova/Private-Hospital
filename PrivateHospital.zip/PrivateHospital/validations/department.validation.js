const Joi = require('joi');

exports.departmentValidation = (data) => {
    const departmentSchema = Joi.object({
        department_name: Joi.string().trim().required(),
        description: Joi.string().trim().default(''),
        head_of_department: Joi.string().length(50).required(),
        contact_number: Joi.string().pattern(/^\+?[1-9]\d{1,14}$/).trim().required(),
        email: Joi.string().email().trim().required(),
        location: Joi.string().trim().required(),
        operating_hours: Joi.string().trim().required(),
        services_offered: Joi.array().items(Joi.string()).default([]),
        number_of_staff: Joi.number().integer().min(1).required(),
    });
    return departmentSchema.validate(data, { abortEarly: false });
};
