const { errorHandler } = require("../helpers/error_handler");
const Doctor = require("../schemas/doctor");
const { doctorValidation } = require("../validations/doctor.validation");
const bcrypt = require('bcrypt');
const config = require("config");
const myJwt = require("../services/jwt_service");
const { to } = require("../helpers/to_promise");
const uuid = require("uuid");
const mail_service = require("../services/mail.service");

// -------------------------ADD-----------------------------------------------------------
const addDoctor = async (req, res) => {
  try {
    const {error, value} = doctorValidation(req.body);
    if (error) {
      return res.status(400).send({ message: error.message });
    }
    console.log(value);
    const {
        fullname,
        birth_date,
        gender,
        email,
        password,
        phone,
        address,
        specialization_id,
        experience,
        qualification_id,
        consultation_fee,
        available_hours,
        department_id,
        active_status
    } = value;
    const hashedPassword = bcrypt.hashSync(password, 7)
    const activation_link = uuid.v4()

    const newDoctor = await Doctor.create({
        fullname,
        birth_date,
        gender,
        email,
        password: hashedPassword,
        phone,
        address,
        specialization_id,
        experience,
        qualification_id,
        consultation_fee,
        available_hours,
        department_id,
        active_status
    });

    await mail_service.sendActivationMail(email, `${config.get("api_url")}:${config.get("port")}/api/doctor/activate/${activation_link}`)

    const payload = {
      _id: newDoctor._id,
      email: newDoctor.email
    }
  
    const tokens = myJwt.generateTokens(payload);
    newDoctor.token = tokens.refreshToken;
    await newDoctor.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })

    res
      .status(201)
      .send({ 
        message: "New Doctor added successfully!", 
        id: newDoctor._id,
        accesstoken: tokens.accessToken });
  } catch (error) {
    errorHandler(res, error);
  }
};

// -------------------------------------LOGIN---------------------------------------------------
const loginDoctor = async(req, res) => {
  try {
    const {email, password} = req.body
    const Doctor = await Doctor.findOne({email})
    if(!Doctor) {
      return res.status(400).send({message: "Email yoki password noto'g'ri!"})
    }
    const validPassword =bcrypt.compareSync(password, Author.password)
    if(!validPassword){
       return res
         .status(400)
         .send({ message: "Email yoki password noto'g'ri!" });
    }
   
    const payload = {
      _id: Doctor._id,
      email: Doctor.email,
      doctor_roles: ["READ", "WRITE"] //"DELETE"
    }
  
    const tokens = myJwt.generateTokens(payload);
    Doctor.token = tokens.refreshToken;
    await Doctor.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })
    res.send({message: "User logged in successfully!", id: Doctor._id, accessToken: tokens.accessToken})
  } catch (error) {
    errorHandler(res, error)
  }
} 

// -----------------------------LOGOUT-----------------------------------------

const logoutDoctor = async (req, res) => {
  const {refreshToken} = req.cookies;
  console.log(refreshToken)
  if(!refreshToken){
    return res.status(403).send({message: "Refresh token topilmadi!"})
  }
  const doctor = await Doctor.findOneAndUpdate(
    {token: refreshToken},
    {token: ""},
    {new: true}
  )
  if(!doctor){
    return res.status(400).send({message: "Invalid refresh token"})
  }
  res.clearCookie("refreshToken")
  res.send({refreshToken: doctor.token})
}

// --------------------------------refreshToken----------------------------------------------
const refreshToken = async(req, res) => {
  try {
    const {refreshToken} = req.cookies;
  console.log(refreshToken)

  if(!refreshToken){
    return res.status(403).send({message: "Cookieda refresh token topilmadi!"})
  }
  const [error, decodedRefreshToken] = await to(myJwt.verifyRefreshToken(refreshToken))
  if(error){
    return res.status(403).send({error: error.message})
  }
  const doctorFromDB = await Doctor.findOne({token: refreshToken});
  if(!doctorFromDB) {
    return res.status(403).send({message: "Ruxsat etilmagan foydalanuvchi(Refreshtoken mos emas)"})
  }
  const payload = {
    _id: doctorFromDB._id,
    email: doctorFromDB.email
  }
  const tokens = myJwt.generateTokens(payload);
  doctorFromDB.token = tokens.refreshToken;
  await doctorFromDB.save();

  res.cookie("refreshToken", tokens.refreshToken, {
    httpOnly: true,
    maxAge: config.get("refresh_time_ms"),
  })
  res.send({message: "Token refreshshed successfully!", id: doctorFromDB._id, accessToken: tokens.accessToken})
  } catch (error) { 
    errorHandler(res, error)
  }
}

// ------------------------------------------GET-----------------------------------------------
const getDoctors = async (req, res) => {
  try {
    const id = req.params.id;
    console.log(id);
    console.log(req.doctor._id);

    if(id !==req.doctor._id){
      return res.status(403).send({message: "Ruxsat etilmagan foydalanuvchi!"})
    }

    // throw badRequest

    const Doctors = await Doctor.find();
    res.send(Doctors);
  } catch (error) {
    // errorHandler(res, error);
  }
};

// ------------------------getById---------------------------------------------------------

const getDoctorById = async (req, res) => {

  try {
    const doctorId = req.params.id
    console.log(doctorId)
    if (!doctorId == req.doctor._id){
      return res.status(403)
      .send({massage: "Ruxsat etilmagan foydalanuvchi "});
    }
    const { id } = req.params;
    const doctor = await Doctor.findById(id);
    if (!doctor) return res.status(404).send({ message: "Doctor is not available!" });
    res.send(doctor);
  } catch (error) {
    errorHandler(res, error);
  }
};
// ----------------------------------------UPDATE----------------------------------------------
const updateDoctorById = async (req, res) => {
  try {
    const { id } = req.params;
    const {
        fullname,
        birth_date,
        gender,
        email,
        password,
        phone,
        address,
        specialization_id,
        experience,
        qualification_id,
        consultation_fee,
        available_hours,
        department_id,
        active_status
    } = req.body;
    const updated_Doctor = await Doctor.findByIdAndUpdate(
      id,
      {
        fullname,
        birth_date,
        gender,
        email,
        password,


        phone,
        address,
        specialization_id,
        experience,
        qualification_id,
        consultation_fee,
        available_hours,
        department_id,
        active_status
      },
      { new: true, runValidators: true }
    );
    if (!updated_Doctor) {
      res.status(404).send({ statuscode: 404, message: "Doctor not found!" });
    }
    return res.status(200).send({
      statuscode: 200,
      message: "Doctor updated successfully!",
      data: updated_Doctor,
    });
  } catch (error) {
    console.log(res, error);
  }
};
// -----------------------------------------DELETE-----------------------------------------

const deleteDoctorById = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted_Doctor = await Doctor.findByIdAndDelete(id);
    if (!deleted_Doctor) {
      res.status(404).send({ statuscode: 404, message: "Doctor not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Doctor deleted successfully!",
      data: deleted_Doctor,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

// ---------------------------------Activate---------------------
const doctorActivate = async (req, res) => {
  try {
    const link = req.params.link
    console.log(link)
    const doctor = await Doctor.findOne({activation_link: link})
    if(!doctor){
      return res.status(400).send({message: "Bunday doktor topilmadi!"})
    }
    if(doctor.is_active){
      return res.status(400).send({message: "Bu doktor avval faollashtirilgan!"})
    }
    doctor.is_active = true
    await doctor.save()

    res.send({is_active: doctor.is_active, message: "Doktor faollashtirildi!"})
  } catch (error) {
    errorHandler(res, error)
  }
}

// -----------------------------------------EXPORT---------------------------------------------
module.exports = {
  addDoctor,
  getDoctors,
  updateDoctorById,
  deleteDoctorById, 
  loginDoctor,
  logoutDoctor,
  getDoctorById,
  refreshToken,
  doctorActivate
};

