const express = require("express");
const mongoose = require("mongoose");
const config = require("config");
const { errorHandler } = require("./helpers/error_handler");
const port = config.get("port");
const mainRouter = require("./routes/index.routes");
const cookieParser = require("cookie-parser");
const error_handling_middleware = require("./middleware/error_handling_middleware");

const app = express();

app.use(express.json());
app.use(cookieParser());
app.use("/api", mainRouter);
app.use(error_handling_middleware);

async function start(){
    try {
        await mongoose.connect(config.get("dbUri"))
        console.log(`Server started at ${port}`);
    } catch (error) {
        console.log(error);
    }
}

start();
