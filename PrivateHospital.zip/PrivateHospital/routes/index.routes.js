const express = require("express");
const indexRouter = express.Router();

const doctorRouter = require("./doctor.routes");

indexRouter.use("/doctor", doctorRouter);

module.exports = indexRouter;