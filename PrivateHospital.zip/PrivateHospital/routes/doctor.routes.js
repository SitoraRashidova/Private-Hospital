
const express = require("express");
const router = express.Router();
const doctorPolice = require("../middleware/doctor_police")
const doctorRolesPolice = require("../middleware/doctor_roles_police");
const { getDoctorById, getDoctors, logoutDoctor, doctorActivate, refreshToken, addDoctor, loginDoctor, updateDoctorById, deleteDoctorById } = require("../controllers/doctor.controller");


router.get("/:id",doctorRolesPolice(["READ"]), getDoctorById)
router.get("/", getDoctors);
router.get("/logout", logoutDoctor);
router.get("/activate/:link", doctorActivate)
router.post("/refresh", refreshToken);
router.post("/create", addDoctor);
router.post("/login", loginDoctor);
router.patch("/update/:id", updateDoctorById);
router.delete("/delete/:id", deleteDoctorById);




module.exports = router;